# frozen_string_literal: true

require 'minitest/autorun'
require 'minitest/unit'
