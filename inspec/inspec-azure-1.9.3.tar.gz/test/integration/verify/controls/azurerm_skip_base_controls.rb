require_controls 'azure' do
  # skip controls from base profile
end
